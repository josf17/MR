package com.zipline.platform.u202519273.routing.interfaces.rest.transform;

import com.zipline.platform.u202519273.routing.domain.model.valueobjects.RouteCode;
import com.zipline.platform.u202519273.routing.domain.model.valueobjects.RouteStatus;

public class RoutingValueObjectFromStringAssembler {
    public static RouteCode toRouteCodeFromString(String value) {
        return new RouteCode(value);
    }

    public static RouteStatus toRouteStatusFromString(String value) {
        if (value == null || value.isBlank()) return RouteStatus.SCHEDULED;
        try {
            return RouteStatus.valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException exception) {
            throw new IllegalArgumentException("routing.flight-route.error.status-invalid");
        }
    }
}
