package com.zipline.platform.u202519273.routing.interfaces.rest.resources;

public record FlightRouteResource(
        Long id,
        String routeCode,
        Double originLatitude,
        Double originLongitude,
        Double destinationLatitude,
        Double destinationLongitude,
        Double cargoWeight,
        Double calculatedDistance,
        String status
) {
}
