package com.zipline.platform.u202519273.routing.domain.model.valueobjects;

public enum RouteStatus {
    SCHEDULED,
    ACTIVE,
    COMPLETED
}
