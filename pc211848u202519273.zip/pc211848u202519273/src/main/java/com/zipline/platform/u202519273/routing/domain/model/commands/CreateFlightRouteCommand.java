package com.zipline.platform.u202519273.routing.domain.model.commands;

import com.zipline.platform.u202519273.routing.domain.model.valueobjects.RouteCode;
import com.zipline.platform.u202519273.routing.domain.model.valueobjects.RouteStatus;
import com.zipline.platform.u202519273.shared.model.valueobjects.GeoPoint;

public record CreateFlightRouteCommand(
        RouteCode routeIdentifier,
        GeoPoint origin,
        GeoPoint destination,
        Double cargoWeight,
        RouteStatus status,
        String notes
) {
    public CreateFlightRouteCommand {
        if (routeIdentifier == null) throw new IllegalArgumentException("routing.flight-route.error.route-code-not-blank");
        if (origin == null) throw new IllegalArgumentException("routing.flight-route.error.origin-latitude-required");
        if (destination == null) throw new IllegalArgumentException("routing.flight-route.error.destination-latitude-required");
        if (cargoWeight == null) throw new IllegalArgumentException("routing.flight-route.error.cargo-weight-required");
    }
}
