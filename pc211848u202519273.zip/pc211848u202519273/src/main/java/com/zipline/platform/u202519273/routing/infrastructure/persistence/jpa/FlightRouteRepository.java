package com.zipline.platform.u202519273.routing.infrastructure.persistence.jpa;

import com.zipline.platform.u202519273.routing.domain.model.aggregates.FlightRoute;
import com.zipline.platform.u202519273.routing.domain.model.valueobjects.RouteCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FlightRouteRepository extends JpaRepository<FlightRoute, Long> {
    boolean existsByRouteIdentifier(RouteCode routeIdentifier);
}
