package com.zipline.platform.u202519273;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@EnableJpaAuditing
@SpringBootApplication
public class Pc211848u202519273Application {
    public static void main(String[] args) {
        SpringApplication.run(Pc211848u202519273Application.class, args);
    }
}
