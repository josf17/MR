package com.zipline.platform.u202519273.routing.application.commandservices;

import com.zipline.platform.u202519273.routing.domain.model.aggregates.FlightRoute;
import com.zipline.platform.u202519273.routing.domain.model.commands.CreateFlightRouteCommand;
import com.zipline.platform.u202519273.shared.application.result.Result;

public interface FlightRouteCommandService {
    Result<FlightRoute, FlightRouteCommandFailure> handle(CreateFlightRouteCommand command);
}
