package com.zipline.platform.u202519273.routing.interfaces.rest.transform;

import com.zipline.platform.u202519273.routing.application.commandservices.FlightRouteCommandFailure;
import com.zipline.platform.u202519273.routing.domain.model.aggregates.FlightRoute;
import com.zipline.platform.u202519273.shared.application.result.Result;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;

public class ResponseEntityFromFlightRouteCommandResultAssembler {
    public static ResponseEntity<?> toResponseEntityFromResult(Result<FlightRoute, FlightRouteCommandFailure> result, MessageSource messageSource) {
        return result.fold(
                flightRoute -> ResponseEntity.status(HttpStatus.CREATED).body(FlightRouteResourceFromEntityAssembler.toResourceFromEntity(flightRoute)),
                failure -> errorResponse(failure, messageSource)
        );
    }

    private static ResponseEntity<ProblemDetail> errorResponse(FlightRouteCommandFailure failure, MessageSource messageSource) {
        var locale = LocaleContextHolder.getLocale();
        var detail = messageSource.getMessage(failure.messageKey(), null, failure.messageKey(), locale);
        var problemDetail = ProblemDetail.forStatusAndDetail(HttpStatus.UNPROCESSABLE_ENTITY, detail);
        problemDetail.setTitle(messageSource.getMessage("errors.found", null, "Errors found:", locale));
        return ResponseEntity.unprocessableEntity().body(problemDetail);
    }
}
