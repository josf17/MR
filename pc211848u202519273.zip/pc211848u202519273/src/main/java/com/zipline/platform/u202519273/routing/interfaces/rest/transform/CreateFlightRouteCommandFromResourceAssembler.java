package com.zipline.platform.u202519273.routing.interfaces.rest.transform;

import com.zipline.platform.u202519273.routing.domain.model.commands.CreateFlightRouteCommand;
import com.zipline.platform.u202519273.routing.interfaces.rest.resources.CreateFlightRouteResource;
import com.zipline.platform.u202519273.shared.model.valueobjects.GeoPoint;

public class CreateFlightRouteCommandFromResourceAssembler {
    public static CreateFlightRouteCommand toCommandFromResource(CreateFlightRouteResource resource) {
        return new CreateFlightRouteCommand(
                RoutingValueObjectFromStringAssembler.toRouteCodeFromString(resource.routeCode()),
                new GeoPoint(resource.originLatitude(), resource.originLongitude()),
                new GeoPoint(resource.destinationLatitude(), resource.destinationLongitude()),
                resource.cargoWeight(),
                RoutingValueObjectFromStringAssembler.toRouteStatusFromString(resource.status()),
                resource.notes()
        );
    }
}
