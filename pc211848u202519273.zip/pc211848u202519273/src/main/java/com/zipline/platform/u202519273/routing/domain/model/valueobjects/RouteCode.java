package com.zipline.platform.u202519273.routing.domain.model.valueobjects;

import java.util.regex.Pattern;

public record RouteCode(String value) {
    private static final Pattern ROUTE_CODE_PATTERN = Pattern.compile("^ZIP-\\d{5}$");

    public RouteCode {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("routing.flight-route.error.route-code-not-blank");
        }
        if (!ROUTE_CODE_PATTERN.matcher(value).matches()) {
            throw new IllegalArgumentException("routing.flight-route.error.route-code-invalid");
        }
    }
}
