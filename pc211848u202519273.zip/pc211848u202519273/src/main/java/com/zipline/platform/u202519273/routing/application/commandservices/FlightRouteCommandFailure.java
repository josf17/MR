package com.zipline.platform.u202519273.routing.application.commandservices;

public sealed interface FlightRouteCommandFailure permits FlightRouteCommandFailure.Duplicate, FlightRouteCommandFailure.DistanceOutOfRange {
    String messageKey();

    record Duplicate() implements FlightRouteCommandFailure {
        @Override
        public String messageKey() {
            return "routing.flight-route.error.duplicate";
        }
    }

    record DistanceOutOfRange() implements FlightRouteCommandFailure {
        @Override
        public String messageKey() {
            return "routing.flight-route.error.distance-out-of-range";
        }
    }
}
