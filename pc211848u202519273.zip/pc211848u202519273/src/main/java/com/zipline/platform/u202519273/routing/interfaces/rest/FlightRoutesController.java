package com.zipline.platform.u202519273.routing.interfaces.rest;

import com.zipline.platform.u202519273.routing.application.commandservices.FlightRouteCommandService;
import com.zipline.platform.u202519273.routing.interfaces.rest.resources.CreateFlightRouteResource;
import com.zipline.platform.u202519273.routing.interfaces.rest.resources.FlightRouteResource;
import com.zipline.platform.u202519273.routing.interfaces.rest.transform.CreateFlightRouteCommandFromResourceAssembler;
import com.zipline.platform.u202519273.routing.interfaces.rest.transform.ResponseEntityFromFlightRouteCommandResultAssembler;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.context.MessageSource;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/flight-routes")
@Tag(name = "Flight Routes", description = "Flight Routes Management Endpoints")
public class FlightRoutesController {
    private final FlightRouteCommandService flightRouteCommandService;
    private final MessageSource messageSource;

    public FlightRoutesController(FlightRouteCommandService flightRouteCommandService, MessageSource messageSource) {
        this.flightRouteCommandService = flightRouteCommandService;
        this.messageSource = messageSource;
    }

    @PostMapping
    @Operation(summary = "Create a flight route", description = "Creates a new autonomous flight route")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Flight route created", content = @Content(schema = @Schema(implementation = FlightRouteResource.class))),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content(schema = @Schema(implementation = ProblemDetail.class))),
            @ApiResponse(responseCode = "422", description = "Business rule violation", content = @Content(schema = @Schema(implementation = ProblemDetail.class)))
    })
    public ResponseEntity<?> createFlightRoute(@Valid @RequestBody CreateFlightRouteResource resource) {
        var command = CreateFlightRouteCommandFromResourceAssembler.toCommandFromResource(resource);
        var result = flightRouteCommandService.handle(command);
        return ResponseEntityFromFlightRouteCommandResultAssembler.toResponseEntityFromResult(result, messageSource);
    }
}
