package com.zipline.platform.u202519273.routing.interfaces.rest.resources;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record CreateFlightRouteResource(
        @NotBlank(message = "{routing.flight-route.error.route-code-not-blank}")
        String routeCode,
        @NotNull(message = "{routing.flight-route.error.origin-latitude-required}")
        Double originLatitude,
        @NotNull(message = "{routing.flight-route.error.origin-longitude-required}")
        Double originLongitude,
        @NotNull(message = "{routing.flight-route.error.destination-latitude-required}")
        Double destinationLatitude,
        @NotNull(message = "{routing.flight-route.error.destination-longitude-required}")
        Double destinationLongitude,
        @NotNull(message = "{routing.flight-route.error.cargo-weight-required}")
        Double cargoWeight,
        String status,
        String notes
) {
}
