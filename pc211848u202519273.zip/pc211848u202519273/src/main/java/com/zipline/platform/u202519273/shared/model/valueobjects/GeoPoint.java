package com.zipline.platform.u202519273.shared.model.valueobjects;

import jakarta.persistence.Embeddable;
import lombok.Getter;

@Getter
@Embeddable
public class GeoPoint {
    private Double latitude;
    private Double longitude;

    protected GeoPoint() {
    }

    public GeoPoint(Double latitude, Double longitude) {
        if (latitude == null || latitude < -90.0 || latitude > 90.0) {
            throw new IllegalArgumentException("routing.flight-route.error.latitude-range");
        }
        if (longitude == null || longitude < -180.0 || longitude > 180.0) {
            throw new IllegalArgumentException("routing.flight-route.error.longitude-range");
        }
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Double latitude() {
        return latitude;
    }

    public Double longitude() {
        return longitude;
    }
}
