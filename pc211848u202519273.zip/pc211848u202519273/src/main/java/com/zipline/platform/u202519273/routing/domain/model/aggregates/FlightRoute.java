package com.zipline.platform.u202519273.routing.domain.model.aggregates;

import com.zipline.platform.u202519273.routing.domain.model.commands.CreateFlightRouteCommand;
import com.zipline.platform.u202519273.routing.domain.model.valueobjects.RouteCode;
import com.zipline.platform.u202519273.routing.domain.model.valueobjects.RouteStatus;
import com.zipline.platform.u202519273.routing.infrastructure.persistence.jpa.converters.RouteCodeAttributeConverter;
import com.zipline.platform.u202519273.shared.model.valueobjects.GeoPoint;
import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.domain.AbstractAggregateRoot;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;

@Getter
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(uniqueConstraints = {
        @UniqueConstraint(columnNames = {"route_identifier"}, name = FlightRoute.ROUTE_IDENTIFIER_UNIQUE_CONSTRAINT)
})
public class FlightRoute extends AbstractAggregateRoot<FlightRoute> {
    public static final String ROUTE_IDENTIFIER_UNIQUE_CONSTRAINT = "uk_flight_route_route_identifier";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    @Convert(converter = RouteCodeAttributeConverter.class)
    private RouteCode routeIdentifier;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "latitude", column = @Column(name = "origin_latitude", nullable = false)),
            @AttributeOverride(name = "longitude", column = @Column(name = "origin_longitude", nullable = false))
    })
    private GeoPoint origin;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "latitude", column = @Column(name = "destination_latitude", nullable = false)),
            @AttributeOverride(name = "longitude", column = @Column(name = "destination_longitude", nullable = false))
    })
    private GeoPoint destination;

    @Column(nullable = false)
    private Double cargoWeight;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RouteStatus status;

    @Column(length = 1000)
    private String notes;

    @Column(nullable = false, updatable = false)
    @CreatedDate
    private Instant createdAt;

    @Column(nullable = false)
    @LastModifiedDate
    private Instant updatedAt;

    protected FlightRoute() {
    }

    public FlightRoute(CreateFlightRouteCommand command) {
        this.routeIdentifier = command.routeIdentifier();
        this.origin = command.origin();
        this.destination = command.destination();
        this.cargoWeight = command.cargoWeight();
        this.status = command.status() == null ? RouteStatus.SCHEDULED : command.status();
        this.notes = command.notes();
        validateCargoWeight();
    }

    public Double calculateDistanceInKm() {
        final double earthRadiusKm = 6371.0;
        var originLatitudeRadians = Math.toRadians(origin.latitude());
        var destinationLatitudeRadians = Math.toRadians(destination.latitude());
        var latitudeDistance = Math.toRadians(destination.latitude() - origin.latitude());
        var longitudeDistance = Math.toRadians(destination.longitude() - origin.longitude());
        var haversine = Math.sin(latitudeDistance / 2) * Math.sin(latitudeDistance / 2)
                + Math.cos(originLatitudeRadians) * Math.cos(destinationLatitudeRadians)
                * Math.sin(longitudeDistance / 2) * Math.sin(longitudeDistance / 2);
        var angularDistance = 2 * Math.atan2(Math.sqrt(haversine), Math.sqrt(1 - haversine));
        return earthRadiusKm * angularDistance;
    }

    private void validateCargoWeight() {
        if (cargoWeight == null || cargoWeight <= 0.0 || cargoWeight > 3.5) {
            throw new IllegalArgumentException("routing.flight-route.error.cargo-weight-range");
        }
    }
}
