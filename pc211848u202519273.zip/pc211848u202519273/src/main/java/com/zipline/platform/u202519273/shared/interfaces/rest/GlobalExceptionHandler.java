package com.zipline.platform.u202519273.shared.interfaces.rest;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private final MessageSource messageSource;

    public GlobalExceptionHandler(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ProblemDetail> handleValidation(MethodArgumentNotValidException exception) {
        var locale = LocaleContextHolder.getLocale();
        var detail = exception.getBindingResult().getFieldErrors().stream()
                .map(error -> resolve(clean(error.getDefaultMessage())))
                .collect(Collectors.joining(" "));
        var problemDetail = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, detail);
        problemDetail.setTitle(resolve("errors.found"));
        return ResponseEntity.badRequest().body(problemDetail);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ProblemDetail> handleIllegalArgument(IllegalArgumentException exception) {
        var problemDetail = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, resolve(exception.getMessage()));
        problemDetail.setTitle(resolve("errors.found"));
        return ResponseEntity.badRequest().body(problemDetail);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ProblemDetail> handleUnreadable(HttpMessageNotReadableException exception) {
        var problemDetail = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, resolve("routing.flight-route.error.request-invalid"));
        problemDetail.setTitle(resolve("errors.found"));
        return ResponseEntity.badRequest().body(problemDetail);
    }

    private String resolve(String key) {
        return messageSource.getMessage(clean(key), null, clean(key), LocaleContextHolder.getLocale());
    }

    private String clean(String value) {
        if (value == null) return "routing.flight-route.error.request-invalid";
        if (value.startsWith("{") && value.endsWith("}")) return value.substring(1, value.length() - 1);
        return value;
    }
}
