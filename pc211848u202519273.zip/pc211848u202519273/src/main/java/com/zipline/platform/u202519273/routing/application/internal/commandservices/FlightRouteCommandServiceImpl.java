package com.zipline.platform.u202519273.routing.application.internal.commandservices;

import com.zipline.platform.u202519273.routing.application.commandservices.FlightRouteCommandFailure;
import com.zipline.platform.u202519273.routing.application.commandservices.FlightRouteCommandService;
import com.zipline.platform.u202519273.routing.domain.model.aggregates.FlightRoute;
import com.zipline.platform.u202519273.routing.domain.model.commands.CreateFlightRouteCommand;
import com.zipline.platform.u202519273.routing.infrastructure.persistence.jpa.FlightRouteRepository;
import com.zipline.platform.u202519273.shared.application.result.Result;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.zipline.platform.u202519273.routing.domain.model.aggregates.FlightRoute.ROUTE_IDENTIFIER_UNIQUE_CONSTRAINT;

@Service
public class FlightRouteCommandServiceImpl implements FlightRouteCommandService {
    private final FlightRouteRepository flightRouteRepository;

    public FlightRouteCommandServiceImpl(FlightRouteRepository flightRouteRepository) {
        this.flightRouteRepository = flightRouteRepository;
    }

    @Override
    @Transactional
    public Result<FlightRoute, FlightRouteCommandFailure> handle(CreateFlightRouteCommand command) {
        if (flightRouteRepository.existsByRouteIdentifier(command.routeIdentifier())) {
            return duplicateResult();
        }
        var flightRoute = new FlightRoute(command);
        if (isInvalidDistance(flightRoute.calculateDistanceInKm())) {
            return Result.failure(new FlightRouteCommandFailure.DistanceOutOfRange());
        }
        try {
            return Result.success(flightRouteRepository.save(flightRoute));
        } catch (DataIntegrityViolationException exception) {
            if (isDuplicateRouteIdentifierViolation(exception)) {
                return duplicateResult();
            }
            throw exception;
        }
    }

    private Result<FlightRoute, FlightRouteCommandFailure> duplicateResult() {
        return Result.failure(new FlightRouteCommandFailure.Duplicate());
    }

    private boolean isInvalidDistance(Double distance) {
        return distance < 0.5 || distance > 120.0;
    }

    private boolean isDuplicateRouteIdentifierViolation(DataIntegrityViolationException exception) {
        Throwable violationCause = exception;
        while (violationCause != null) {
            String message = violationCause.getMessage();
            if (message != null && message.contains(ROUTE_IDENTIFIER_UNIQUE_CONSTRAINT)) return true;
            violationCause = violationCause.getCause();
        }
        return false;
    }
}
