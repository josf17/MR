package com.zipline.platform.u202519273.routing.infrastructure.persistence.jpa.converters;

import com.zipline.platform.u202519273.routing.domain.model.valueobjects.RouteCode;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

@Converter(autoApply = false)
public class RouteCodeAttributeConverter implements AttributeConverter<RouteCode, String> {
    @Override
    public String convertToDatabaseColumn(RouteCode attribute) {
        return attribute == null ? null : attribute.value();
    }

    @Override
    public RouteCode convertToEntityAttribute(String dbData) {
        return dbData == null ? null : new RouteCode(dbData);
    }
}
