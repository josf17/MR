package com.zipline.platform.u202519273.routing.interfaces.rest.transform;

import com.zipline.platform.u202519273.routing.domain.model.aggregates.FlightRoute;
import com.zipline.platform.u202519273.routing.interfaces.rest.resources.FlightRouteResource;

public class FlightRouteResourceFromEntityAssembler {
    public static FlightRouteResource toResourceFromEntity(FlightRoute entity) {
        return new FlightRouteResource(
                entity.getId(),
                entity.getRouteIdentifier().value(),
                entity.getOrigin().latitude(),
                entity.getOrigin().longitude(),
                entity.getDestination().latitude(),
                entity.getDestination().longitude(),
                entity.getCargoWeight(),
                entity.calculateDistanceInKm(),
                entity.getStatus().name()
        );
    }
}
