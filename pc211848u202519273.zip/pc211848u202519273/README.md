# Zipline Platform

RESTful API made with Java and Spring Boot for the Zipline PC2 practice.

## Student

Josue Carpio - u202519273

## Database

- Schema: zipline_platform
- User: root
- Password: mysql

## Endpoint

POST /api/v1/flight-routes

## Run

```bash
./mvnw spring-boot:run
```

Swagger:

```text
http://localhost:8080/swagger-ui/index.html
```
